
mnm - v2 2020-10-10 12:29pm
==============================

This dataset was exported via roboflow.ai on October 10, 2020 at 9:30 AM GMT

It includes 4 images.
Toymnm are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


